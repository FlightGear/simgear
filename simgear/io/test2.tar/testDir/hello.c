#include <cstdio>

int main(int arcg, char* argv)
{
  return EXIT_SUCCESS;
}
